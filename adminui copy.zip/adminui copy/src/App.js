import './App.css';
import Table from './Components/Table';

function App() {
  return (
    <div className="App">
      <Table />

      
    </div>
  );
}

export default App;
